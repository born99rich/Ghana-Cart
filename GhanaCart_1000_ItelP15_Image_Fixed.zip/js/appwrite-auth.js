import { Client, Account, OAuthProvider, ID } from 'https://cdn.jsdelivr.net/npm/appwrite@latest/+esm';

const client = new Client()
  .setEndpoint('https://nyc.cloud.appwrite.io/v1')
  .setProject('6abb1e7300052f73d9a6');

export const account = new Account(client);
export { OAuthProvider };

export async function signInWithGoogle() {
  const success = `${window.location.origin}/auth-success.html`;
  const failure = `${window.location.origin}/auth-failure.html`;
  await account.createOAuth2Token({
    provider: OAuthProvider.Google,
    success,
    failure,
  });
}

export async function signInWithEmail(email, password) {
  const session = await account.createEmailPasswordSession({ email, password });
  const user = await account.get();
  localStorage.setItem('gc_user', JSON.stringify({
    name: user.name || user.email?.split('@')[0] || 'GhanaCart customer',
    email: user.email || '',
    photo: user.prefs?.photo || '',
    provider: 'email',
    appwriteUserId: user.$id,
  }));
  return { session, user };
}

export async function signUpWithEmail(name, email, password) {
  await account.create({
    userId: ID.unique(),
    name,
    email,
    password,
  });
  return await signInWithEmail(email, password);
}

export async function createSessionFromCallback() {
  const url = new URL(window.location.href);
  const secret = url.searchParams.get('secret');
  const userId = url.searchParams.get('userId');
  if (!secret || !userId) throw new Error('Missing OAuth credentials');

  await account.createSession({ userId, secret });
  const user = await account.get();
  localStorage.setItem('gc_user', JSON.stringify({
    name: user.name || user.email?.split('@')[0] || 'GhanaCart customer',
    email: user.email || '',
    photo: user.prefs?.photo || '',
    provider: 'google',
    appwriteUserId: user.$id,
  }));
  return user;
}

export async function loadCurrentUser() {
  return await account.get();
}

export async function signOut() {
  await account.deleteSession({ sessionId: 'current' });
  localStorage.removeItem('gc_user');
}

export async function updateUserPrefs(prefs) { return await account.updatePrefs(prefs); }
