(function(){
  const render=()=>{
    const el=document.querySelector('#categories');if(!el||!window.GhanaCart)return;
    el.innerHTML=Object.entries(GhanaCart.DEPARTMENTS).filter(([k])=>GhanaCart.REAL_PRODUCTS.some(p=>p.departmentKey===k)).map(([k,d])=>{
      const count=GhanaCart.REAL_PRODUCTS.filter(p=>p.departmentKey===k).length;
      return `<a class="panel" href="category.html?category=${encodeURIComponent(k)}"><div style="font-size:36px">${d.icon}</div><h2>${d.name}</h2><p class="muted"><span data-category-count="${k}">${count.toLocaleString()}</span> product listings · real catalog source</p><span class="btn secondary">Open category</span></a>`;
    }).join('');
  };
  document.addEventListener('DOMContentLoaded',()=>{render();window.addEventListener('ghanacart:catalog-ready',render);});
})();
