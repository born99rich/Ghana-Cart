(function(){
  const $=id=>document.getElementById(id);
  const required=['id','sku','name','brand','model','departmentKey','type','price','images'];
  function parseCSV(text){
    const rows=[];let row=[],cell='',quote=false;
    for(let i=0;i<text.length;i++){const c=text[i];if(c==='"'){if(quote&&text[i+1]==='"'){cell+='"';i++;}else quote=!quote;}else if(c===','&&!quote){row.push(cell);cell='';}else if((c==='\n'||c==='\r')&&!quote){if(c==='\r'&&text[i+1]==='\n')i++;row.push(cell);if(row.some(v=>v.trim()))rows.push(row);row=[];cell='';}else cell+=c;}
    if(cell||row.length){row.push(cell);rows.push(row)}
    const headers=rows.shift().map(x=>x.trim());return rows.map(r=>Object.fromEntries(headers.map((h,i)=>[h,(r[i]||'').trim()])));
  }
  function normalize(p){
    const images=Array.isArray(p.images)?p.images:(typeof p.images==='string'?p.images.split('|').map(x=>x.trim()).filter(Boolean):[]);
    return {...p,id:String(p.id||'').trim(),sku:String(p.sku||'').trim(),name:String(p.name||'').trim(),brand:String(p.brand||'').trim(),model:String(p.model||'').trim(),departmentKey:String(p.departmentKey||'').trim(),type:String(p.type||'').trim(),price:Number(p.price),images};
  }
  function validate(list){
    const errors=[],ids=new Set(),skus=new Set(),models=new Set();
    list.forEach((raw,i)=>{const p=normalize(raw),line=i+2;required.forEach(k=>{if(p[k]===undefined||p[k]===''||(k==='images'&&!p.images.length))errors.push(`Row ${line}: missing ${k}`)});if(p.id&&ids.has(p.id))errors.push(`Row ${line}: duplicate id ${p.id}`);if(p.sku&&skus.has(p.sku))errors.push(`Row ${line}: duplicate SKU ${p.sku}`);const mk=[p.brand,p.model,p.color,p.size].join('|').toLowerCase();if(p.brand&&p.model&&models.has(mk))errors.push(`Row ${line}: duplicate product/variant ${p.brand} ${p.model}`);if(p.price<0||Number.isNaN(p.price))errors.push(`Row ${line}: invalid price`);p.images.forEach(u=>{if(!/^https:\/\//i.test(u))errors.push(`Row ${line}: image is not HTTPS: ${u}`)});if(p.id)ids.add(p.id);if(p.sku)skus.add(p.sku);if(mk!=='|||')models.add(mk)});return errors;
  }
  $('validate').onclick=async()=>{const f=$('file').files[0];if(!f){$('status').textContent='Choose a CSV/JSON feed first.';return}const text=await f.text();let list=[];try{if(/\.csv$/i.test(f.name))list=parseCSV(text);else if(/\.ndjson$|\.txt$/i.test(f.name))list=text.split(/\r?\n/).filter(Boolean).map(JSON.parse);else list=JSON.parse(text);if(!Array.isArray(list))list=list.products||[];}catch(e){$('status').textContent='Could not parse the file: '+e.message;return}const errors=validate(list);$('status').innerHTML=`<strong>${list.length.toLocaleString()} records checked.</strong> ${errors.length?'Rejected: '+errors.length+' errors.':'Validation passed.'}`;$('errors').innerHTML=errors.length?'<pre style="white-space:pre-wrap">'+errors.slice(0,300).map(x=>x.replace(/[&<>]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]))).join('\n')+'</pre>':'<p>All required fields, uniqueness checks and HTTPS image URL checks passed. Export the validated feed into GhanaCart’s catalog pipeline rather than generating synthetic products.</p>'};
})();
