// GhanaCart Appwrite Google OAuth configuration.
// OAuth client secrets are intentionally NOT stored in frontend code.
window.GHANCART_AUTH_CONFIG = {
  provider: 'google',
  appwriteEndpoint: 'https://nyc.cloud.appwrite.io/v1',
  projectId: '6abb1e7300052f73d9a6',
  googleOAuthCallback: 'https://nyc.cloud.appwrite.io/v1/account/sessions/oauth2/callback/google/6abb1e7300052f73d9a6'
};
