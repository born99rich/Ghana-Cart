/* GhanaCart large catalog loader — real source records only.
 * Source: Shopify Product Catalogue (Apache-2.0) via Hugging Face Dataset Viewer.
 * No synthetic product records and no cross-product image substitution.
 */
(function(){
  const TARGET=1000;
  const BATCH=100;
  const MAX_OFFSET=38600;
  const API='https://datasets-server.huggingface.co/rows?dataset=Shopify%2Fproduct-catalogue&config=default&split=train&offset=OFFSET&length=100';
  const ICONS={phones:'📱',electronics:'📺',computing:'💻',fashion:'👕',beauty:'💄','home-kitchen':'🏠',grocery:'🛒',sports:'⚽',toys:'🧸',baby:'🍼',automotive:'🚗',arts:'🎨',industrial:'🛠️',pets:'🐾','books-media':'📚',furniture:'🪑',other:'🛍️'};
  const NAMES={phones:'Phones & Tablets',electronics:'Electronics',computing:'Computers & Office',fashion:'Fashion',beauty:'Health & Beauty','home-kitchen':'Home & Garden',grocery:'Grocery & Food',sports:'Sports & Fitness',toys:'Toys & Games',baby:'Baby & Toddler',automotive:'Automotive',arts:'Arts & Entertainment',industrial:'Industrial & Tools',pets:'Pet Supplies','books-media':'Books & Media',furniture:'Furniture',other:'More Products'};
  function topCategory(cat){
    const t=String(cat||'').split('>')[0].trim().toLowerCase();
    if(/phone|tablet/.test(t))return 'phones';
    if(/computer|office/.test(t))return 'computing';
    if(/electronics|camera|optic/.test(t))return 'electronics';
    if(/apparel|fashion|clothing|accessories|shoe|footwear|sneaker|boot|sandals?/.test(t))return 'fashion';
    if(/health|beauty/.test(t))return 'beauty';
    if(/furniture/.test(t))return 'furniture';
    if(/home|garden|kitchen/.test(t))return 'home-kitchen';
    if(/food|beverages|tobacco/.test(t))return 'grocery';
    if(/sport/.test(t))return 'sports';
    if(/toy|games/.test(t))return 'toys';
    if(/baby|toddler/.test(t))return 'baby';
    if(/vehicle|automotive|parts/.test(t))return 'automotive';
    if(/arts|entertainment|hobbies/.test(t))return 'arts';
    if(/business|industrial|hardware/.test(t))return 'industrial';
    if(/animal|pet/.test(t))return 'pets';
    if(/media|book|music|movie/.test(t))return 'books-media';
    return 'other';
  }
  function leaf(cat){const a=String(cat||'').split('>').map(x=>x.trim()).filter(Boolean);return a[a.length-1]||'Product'}
  function mapRow(x){
    const r=x?.row||{};
    const title=String(r.product_title||'').trim();
    const image=r.product_image?.src||'';
    const category=String(r.ground_truth_category||'').trim();
    if(!title||!image||!/^https?:\/\//i.test(image)||!category)return null;
    const key=topCategory(category), idx=Number(x.row_idx);
    const id=900000000+(Number.isFinite(idx)?idx:Math.floor(Math.random()*100000));
    const brand=String(r.ground_truth_brand||'').trim();
    const description=String(r.product_description||'').replace(/\s+/g,' ').trim();
    return {id,sku:`HF-SHOPIFY-${idx}`,name:title,brand:brand||'Unbranded',model:title,departmentKey:key,department:NAMES[key],type:leaf(category),color:'',size:'',price:null,old:null,discount:0,stock:0,freeShipping:false,deliveryDays:3,feature:description.slice(0,160)||leaf(category),material:'',short:title,description:description||title,images:[image],sourceUrl:'https://huggingface.co/datasets/Shopify/product-catalogue',catalogSource:'Shopify Product Catalogue / Hugging Face',priceStatus:'pending_supplier_price',categoryPath:category};
  }
  const CATEGORY_QUERIES={
    phones:['phone','smartphone','tablet'],electronics:['electronics','television','audio'],computing:['computer','laptop','office'],fashion:['apparel','clothing','shoes'],beauty:['health','beauty','cosmetic'],
    'home-kitchen':['home','garden','kitchen'],grocery:['food','beverage','grocery'],sports:['sport','fitness','outdoor'],toys:['toy','game'],baby:['baby','toddler','nursery'],
    automotive:['vehicle','automotive','car'],arts:['arts','entertainment','hobby'],industrial:['hardware','industrial','tools'],pets:['pet','animal'],
    'books-media':['book','media','music'],furniture:['furniture','chair','table'],other:['other']
  };
  // Focused storefront categories: these are filled from the same real Shopify catalogue,
  // so each category can show a large selection instead of empty placeholder sections.
  const EXTRA_CATEGORY_DEFS={
    'android-phones':{name:'Android Phones',icon:'📱',queries:['android phone','android smartphone','5g phone']},
    'keypad':{name:'Keypad & Dual SIM',icon:'📞',queries:['keypad phone','feature phone','dual sim phone']},
    'watches':{name:'Watches & Smartwatches',icon:'⌚',queries:['smartwatch','watch','fitness watch']},
    'home-kitchen':{name:'Home & Kitchen',icon:'🏠',queries:['kitchen','home appliance','blender','microwave','air fryer','cookware']},
    'accessories':{name:'Phone Accessories',icon:'🔌',queries:['phone case','phone charger','power bank','usb cable','screen protector']},
    'laptops':{name:'Laptops & Notebooks',icon:'💻',queries:['HP laptop','HP notebook','HP EliteBook','HP ProBook','HP Pavilion','HP Envy','HP Spectre','HP OmniBook','HP Omen','Lenovo laptop','Lenovo notebook','Lenovo ThinkPad','Lenovo IdeaPad','Lenovo Yoga','Lenovo Legion','Lenovo LOQ','Lenovo ThinkBook','Dell laptop','Dell notebook','Dell Inspiron','Dell Latitude','Dell XPS','Dell Vostro','Dell Precision','Alienware laptop','ASUS laptop','ASUS VivoBook','ASUS Zenbook','ASUS ROG','ASUS TUF','Acer laptop','Acer Aspire','Acer Swift','Acer Nitro','Acer Predator','Apple MacBook','MacBook Air','MacBook Pro','Microsoft Surface Laptop','MSI laptop','MSI Modern','MSI Prestige','MSI Katana','MSI Raider','Razer Blade','Samsung Galaxy Book','LG Gram','Huawei MateBook','Gigabyte AERO','Gigabyte AORUS','Framework Laptop','laptop','notebook computer','ultrabook'],brandAllow:['HP','Hewlett-Packard','Lenovo','Dell','Alienware','ASUS','Asus','Acer','Apple','Microsoft','MSI','Razer','Samsung','LG','Huawei','Gigabyte','Framework']},
    'gaming':{name:'Gaming',icon:'🎮',queries:['gaming','game console','gaming accessories']},
    'audio':{name:'Headphones & Audio',icon:'🎧',queries:['headphones','earphones','speaker','audio']},
    'cameras':{name:'Cameras & Photography',icon:'📷',queries:['camera','digital camera','photography']},
    'tv-video':{name:'TV & Video',icon:'📺',queries:['television','TV','video projector','DVD']},
    'bags-luggage':{name:'Bags & Luggage',icon:'👜',queries:['bags','handbags','backpack','luggage','suitcase']},
    'jewelry':{name:'Jewelry & Accessories',icon:'💎',queries:['jewelry','jewellery','necklace','bracelet','ring']},
    'kitchen-appliances':{name:'Kitchen Appliances',icon:'🍳',queries:['kitchen appliance','blender','air fryer','microwave','coffee maker']},
    'home-decor':{name:'Home Decor & Lighting',icon:'🛋️',queries:['home decor','home decoration','lighting','lamp','wall decor']},
    'furniture-home':{name:'Furniture',icon:'🪑',queries:['furniture','sofa','chair','table','bed']},
    'beauty-cosmetics':{name:'Beauty & Cosmetics',icon:'💄',queries:['cosmetics','makeup','skincare','beauty']},
    'fitness':{name:'Fitness & Exercise',icon:'🏋️',queries:['fitness','exercise','gym','workout','yoga']},
    'outdoor':{name:'Outdoor & Camping',icon:'⛺',queries:['camping','outdoor','hiking','tent']},
    'baby-essentials':{name:'Baby Essentials',icon:'🍼',queries:['baby','infant','nursery','toddler']},
    'pet-supplies':{name:'Pet Supplies',icon:'🐶',queries:['pet','dog','cat','animal']},
    'office-school':{name:'Office & School Supplies',icon:'📚',queries:['office supplies','school supplies','stationery','notebook']},
    'tools-hardware':{name:'Tools & Hardware',icon:'🛠️',queries:['tools','hardware','drill','hand tools']},
    'car-accessories':{name:'Car Accessories & Parts',icon:'🚗',queries:['car accessories','auto parts','automotive','vehicle']},
    'groceries-food':{name:'Groceries & Food',icon:'🛒',queries:['grocery','food','snack','beverage']},
    'books-media-store':{name:'Books, Music & Media',icon:'📚',queries:['books','music','media','movie']}
  };
  Object.entries(EXTRA_CATEGORY_DEFS).forEach(([key,d])=>registerCatalogDepartment(key,d.name,d.icon));
  async function fetchSearch(query,offset){
    const u='https://datasets-server.huggingface.co/search?dataset=Shopify%2Fproduct-catalogue&config=default&split=train&query='+encodeURIComponent(query)+'&offset='+offset+'&length=100';
    const r=await fetch(u,{mode:'cors',cache:'no-store'});if(!r.ok)throw new Error('HTTP '+r.status);return r.json();
  }
  async function fillExtraCategories(minimum=300){
    const existingIds=new Set(GhanaCart.REAL_PRODUCTS.map(p=>String(p.id)));
    const fingerprints=new Set(GhanaCart.REAL_PRODUCTS.map(p=>`${String(p.brand||'').toLowerCase()}|${String(p.name||'').toLowerCase()}|${String(p.model||'').toLowerCase()}`));
    const imageSeenByCategory={};
    for(const [key,def] of Object.entries(EXTRA_CATEGORY_DEFS)){
      let count=GhanaCart.REAL_PRODUCTS.filter(p=>p.departmentKey===key).length;
      const target=key==='laptops'?300:(['keypad','watches','home-kitchen','accessories'].includes(key)?130:(['mens-fashion','womens-fashion','shoes','bags-luggage','jewelry','beauty-cosmetics'].includes(key)?320:minimum));
      if(count>=target)continue;
      for(const q of def.queries){
        if(count>=target)break;
        for(let page=0;page<12 && count<target;page++){
          let data;
          try{data=await fetchSearch(q,page*100)}catch(e){continue}
          for(const x of (data.rows||[])){
            if(count>=target)break;
            const p=mapRow(x); if(!p)continue;
            const hay=`${p.name} ${p.description} ${p.categoryPath}`.toLowerCase();
            const qwords=q.toLowerCase().split(/\s+/).filter(w=>w.length>2);
            if(!qwords.some(w=>hay.includes(w)))continue;
            if(key==='laptops'){
              const allowed=def.brandAllow||[];
              const brandHay=`${p.brand} ${p.name}`.toLowerCase();
              const isLaptop=/\b(laptop|notebook|macbook|thinkpad|ideapad|elitebook|probook|pavilion|envy|spectre|omnibook|inspiron|latitude|vostro|precision|xps|alienware|vivobook|zenbook|rog|tuf|aspire|swift|nitro|predator|surface laptop|katana|raider|blade|galaxy book|gram|matebook|aero|aorus|framework)\b/i.test(hay);
              const hasAllowed=allowed.some(b=>brandHay.includes(String(b).toLowerCase()));
              if(!isLaptop || !hasAllowed)continue;
            }
            const fp=`${p.brand.toLowerCase()}|${p.name.toLowerCase()}|${p.model.toLowerCase()}`;
            const imgKey=String(p.images?.[0]||''); imageSeenByCategory[key]=imageSeenByCategory[key]||new Set(); if(imageSeenByCategory[key].has(imgKey))continue; if(fingerprints.has(fp)||existingIds.has(String(p.id)))continue;
            p.id=920000000+Number(x.row_idx||0);
            if(existingIds.has(String(p.id)))continue;
            p.departmentKey=(key==='mens-fashion'||key==='womens-fashion'||key==='shoes')?'fashion':key;p.department=(p.departmentKey==='fashion'?'Fashion':def.name);
            existingIds.add(String(p.id));fingerprints.add(fp);imageSeenByCategory[key].add(imgKey);
            GhanaCart.REAL_PRODUCTS.push(p);count++;
          }
          notify(key);
          if(!(data.rows||[]).length)break;
        }
      }
    }
    notify();
  }

  async function fillMinimumPerCategory(minimum=300){
    ensureDepartments();
    const existing=new Set(GhanaCart.REAL_PRODUCTS.map(p=>String(p.id)));
    const fingerprints=new Set(GhanaCart.REAL_PRODUCTS.map(p=>`${String(p.brand||'').toLowerCase()}|${String(p.name||'').toLowerCase()}|${String(p.model||'').toLowerCase()}`));
    for(const key of Object.keys(CATEGORY_QUERIES)){
      let count=GhanaCart.REAL_PRODUCTS.filter(p=>p.departmentKey===key).length;
      let offset=0;
      for(const q of CATEGORY_QUERIES[key]){
        if(count>=minimum)break;
        for(let page=0;page<6 && count<minimum;page++,offset+=100){
          let data;try{data=await fetchSearch(q,page*100)}catch(e){continue}
          for(const x of (data.rows||[])){
            if(count>=minimum)break;
            const p=mapRow(x);if(!p)continue;
            // Keep the source record's exact image/name, and only accept records relevant to the search query.
            const hay=`${p.name} ${p.description} ${p.categoryPath}`.toLowerCase();
            const qwords=q.toLowerCase().split(/\s+/).filter(w=>w.length>2);
            if(qwords.length && !qwords.some(w=>hay.includes(w)))continue;
            const fp=`${p.brand.toLowerCase()}|${p.name.toLowerCase()}|${p.model.toLowerCase()}`;
            if(fingerprints.has(fp)||existing.has(String(p.id)))continue;
            p.id=910000000+Number(x.row_idx||0);
            if(existing.has(String(p.id)))continue;
            p.departmentKey=key;p.department=NAMES[key];
            existing.add(String(p.id));fingerprints.add(fp);GhanaCart.REAL_PRODUCTS.push(p);count++;
          }
          notify(key);
          if(!(data.rows||[]).length)break;
        }
        offset=0;
      }
    }
    notify();
    return {total:GhanaCart.REAL_PRODUCTS.length};
  }
  window.GhanaCartCategoryMinimum=300;
  window.GhanaCartCategoryStatus=function(){
    if(!window.GhanaCart||!Array.isArray(GhanaCart.REAL_PRODUCTS))return {};
    const out={};
    Object.keys(GhanaCart.DEPARTMENTS||{}).forEach(k=>{out[k]=GhanaCart.REAL_PRODUCTS.filter(p=>p.departmentKey===k).length});
    return out;
  };
  const promise=(async()=>{
    if(window.GhanaCartStaticReady) await window.GhanaCartStaticReady;
    if(!window.GhanaCart||!Array.isArray(GhanaCart.REAL_PRODUCTS))return {added:0,total:0,error:'catalog unavailable'};
    try{
      await fillExtraCategories(300);
      await fillMinimumPerCategory(300);
      // Then continue filling the broad catalog toward the 1,000 target.
      const existing=new Set(GhanaCart.REAL_PRODUCTS.map(p=>`${String(p.brand||'').toLowerCase()}|${String(p.name||'').toLowerCase()}|${String(p.model||'').toLowerCase()}`));
      let added=0;
      for(let offset=0;offset<MAX_OFFSET && GhanaCart.REAL_PRODUCTS.length<TARGET;offset+=BATCH*5){
        const req=[];for(let j=0;j<5 && offset+j*BATCH<MAX_OFFSET;j++)req.push(fetch(API.replace('OFFSET',String(offset+j*BATCH)),{mode:'cors',cache:'no-store'}).then(r=>{if(!r.ok)throw new Error('HTTP '+r.status);return r.json()}));
        const results=await Promise.allSettled(req);let any=false;
        for(const rr of results){if(rr.status!=='fulfilled')continue;for(const x of (rr.value.rows||[])){if(GhanaCart.REAL_PRODUCTS.length>=TARGET)break;const p=mapRow(x);if(!p)continue;const fp=`${p.brand.toLowerCase()}|${p.name.toLowerCase()}|${p.model.toLowerCase()}`;if(existing.has(fp))continue;existing.add(fp);GhanaCart.REAL_PRODUCTS.push(p);added++;any=true;}}
        notify();if(!any&&results.every(x=>x.status!=='fulfilled'))break;
      }
      notify();return {added,total:GhanaCart.REAL_PRODUCTS.length};
    }catch(error){notify();return {added:0,total:GhanaCart.REAL_PRODUCTS.length,error:String(error)}}
  })();
  window.GhanaCart1KReady=promise;
  window.GhanaCart10KReady=promise;
})();
