# GhanaCart — 100K verified catalog workflow

This build is optimized for importing a real catalog of 100,000+ SKUs without pretending that synthetic records are real products.

## How to reach 100K real products
1. Obtain a supplier/manufacturer/marketplace feed containing real SKUs.
2. Map it to `data/PRODUCT_FEED_SCHEMA.json`.
3. Validate it with `catalog-import.html`.
4. Only records with exact model-specific HTTPS images, unique SKUs, valid prices and complete required fields should be published.

Jumia VendorHub documents bulk product creation through Import/Export and CSV templates, which is one practical source format for a seller's own catalog data. It also requires product content and image links for creation. Do not copy another seller's catalog or images without permission.

GS1 Ghana documents GTIN-based product identification and master-data sharing standards, which can be used to improve uniqueness and product identity when suppliers provide GTINs.

The site still displays only verified records. It does not inflate the customer-facing count with invented products.
