# GhanaCart 2M+ Catalog Architecture

This build is **2M+ ready**, not padded with invented products.

## Hard rules
- No generated/fake product records.
- No reused photo for a different model.
- No cross-brand/model substitution.
- Every imported SKU must have a model-specific product image URL.
- Duplicate IDs are rejected.
- Duplicate records are rejected by the supplier/import pipeline.
- Invalid prices and missing required fields are rejected.

## Scale
The catalog engine supports up to 2,500,000 verified SKUs in the browser-side import layer. It loads products in pages from a supplier/catalog feed instead of placing millions of image files in the ZIP.

## Feed format
A feed page can be either an array of products or:

```json
{"products":[...],"next":"https://example.com/catalog?page=2"}
```

Each product must contain:
`id`, `name`, `brand`, `model`, `departmentKey`, `images`, `price`.

Images must be direct HTTP(S) image URLs. Missing/invalid images are rejected.

## Home & Kitchen coverage
The category structure now covers the broader home-delivery scope: furniture, bedroom, living room, dining, bathroom, storage/organization, wardrobes, shoe racks, laundry, cleaning, lighting, home décor, kitchen & dining, cookware, cutlery, knives, chopping boards, utensils, food storage, bakeware, small appliances, large appliances, cooling, water dispensers, office furniture, kids' furniture, nursery and household essentials.

The current verified catalog count is intentionally unchanged until real supplier/catalog records are imported. The number shown to customers must represent real verified SKUs, not a marketing placeholder.
