# GhanaCart — Appwrite Google Sign-In

This package keeps the original GhanaCart static site and SVG image library and adds Appwrite Google OAuth2 with first-party routes.

## Routes
- `/auth` — signed-out Google sign-in screen
- `/auth/success` — reads `userId` and `secret`, calls `account.createSession`, then goes to `/dashboard`
- `/auth/failure` — OAuth failure screen
- `/dashboard` — protected signed-in dashboard with user name/email and Sign out

## Appwrite
- Endpoint: `https://nyc.cloud.appwrite.io/v1`
- Project ID: `6abb1e7300052f73d9a6`
- Provider: Google

The browser uses the Appwrite Web SDK from the latest package via ESM. No Google OAuth client secret is included in frontend code.

Before testing, enable Google in Appwrite Auth > Settings, register `ghanacart.netlify.app` as a Web platform, and configure the Google provider with the Client ID/Secret in Appwrite. Use the redirect URL shown by Appwrite in Google Cloud.

All original product/accessory images remain SVG.

Real phone brands added: Samsung, TECNO and itel. See REAL_PHONE_BRANDS.md.
