# GhanaCart — expanded category catalog

Added visible departments for shoes, bags & luggage, men's fashion, women's fashion, jewelry, audio, cameras, TV/video, kitchen appliances, home decor, furniture, beauty, fitness, outdoor, baby, pets, office/school, tools, automotive, groceries, books/media and Android phones.

Each added department has fallback real product photography records so it is not empty on first load. The live Shopify Product Catalogue loader remains enabled and adds exact source product records and source images when the browser can reach the catalogue service.
