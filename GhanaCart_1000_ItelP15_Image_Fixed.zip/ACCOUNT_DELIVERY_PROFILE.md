# GhanaCart account delivery profile

- Customers can open **My Account** from the signed-in account link.
- Saved fields: full name, phone number, Ghana region, town/city, delivery address and optional delivery note/landmark.
- Checkout pre-fills the saved details so repeat orders do not require retyping them.
- Customers can edit and save the details at any time from My Account.
- Customers can choose a profile picture; the browser resizes it to a small account image and GhanaCart syncs it to the signed-in Appwrite account when possible.
- The customer can still change the checkout fields for an individual order without changing the saved profile.

The implementation follows the familiar account/address-book pattern used by major marketplaces. Jumia documents an account Address Book where customers can add/edit addresses and select a default address.
