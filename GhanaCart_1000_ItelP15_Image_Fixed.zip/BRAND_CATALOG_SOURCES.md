# GhanaCart Brand Catalog Sources

This build expands GhanaCart's verified brand catalog using official brand sources where available and current Ghana marketplace pricing references where a Ghana price is published.

Requested brands covered in the catalog/source registry include:
- Samsung
- Oraimo
- TECNO
- itel
- Apple
- Infinix
- PlayStation / Sony
- Xbox / Microsoft
- TCL
- Hisense
- Nasco
- NIVEA
- Jordan
- Nike
- Puma
- Gucci

Official/current source pages checked for the expansion:
- Samsung Africa: https://www.samsung.com/africa_en/
- Oraimo All Products: https://oraimo.com/en/collections/ALL
- TECNO Ghana: https://www.tecno-mobile.com/gh/
- itel: https://www.itel-life.com/
- Sony Electronics: https://electronics.sony.com/
- PlayStation: https://www.playstation.com/en-us/
- Xbox/Microsoft Store: https://www.microsoft.com/en-us/store/b/xbox
- TCL Global: https://www.tcl.com/global/en
- Hisense Ghana: https://www.hisense.com.gh/shop/category/television-9
- NIVEA Ghana: https://www.nivea.com.gh/products

Ghana price references checked include Jumia Ghana brand/category listings for Samsung, Oraimo, itel, Infinix, NIVEA and Nasco.

## Important catalog rule
A static ZIP cannot truthfully contain every current SKU from every brand named by the user because brand catalogs, stock and Ghana prices change continuously and several official brand sites do not publish Ghana retail prices for every SKU. The build therefore uses verified product records with matched images and current price references where available, while retaining the scalable Shopify catalog loader for broader catalog expansion.
