# GhanaCart real phone brands

This catalog now contains model-specific listings for Samsung, TECNO and itel.

## Brands included
- Samsung: Galaxy A17, A16, A26 5G, A36 5G
- TECNO: CAMON 50, CAMON 50 Pro, CAMON Slim, CAMON 50 Pro 5G, SPARK 50 Pro, SPARK 50 5G
- itel: Super 26 Ultra, POWER 70, CITY 100, A90, POWER 80, A300C

Each listing has an explicit model, variant, GhanaCart price, product description, source URL and model-specific image URL. Manufacturer product pages were used to verify model names/specifications.

## Important image licensing note
The site references manufacturer-hosted product imagery. Before commercial launch, GhanaCart should confirm permission to use each manufacturer's imagery or replace the URLs with product photographs supplied/licensed by the seller or manufacturer.

## Adding another phone
Add one object to `js/catalog.js` with:
- unique `id`
- `brand`, `model`, exact variant and colour
- GhanaCart `price` and optional `old` price
- `images` array containing exact product-photo URLs
- `sourceUrl` pointing to the manufacturer/product source
