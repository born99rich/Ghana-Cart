GhanaCart Budget Pricing

Catalog prices were reduced by approximately 50% for this promotional/demo build. One promotional item is GH₵1: 9H Tempered Glass Screen Protector for iPhone 7/8 — Clear. These are GhanaCart promotional prices, not claims of official manufacturer pricing.
