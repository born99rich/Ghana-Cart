GhanaCart 20,000 Stored Product Catalog

This folder contains 20 JSON files (products-01.json through products-20.json).
Each file contains 1,000 product records, for exactly 20,000 stored marketplace product records.

The website loads these files from /data/ at runtime. The records are intentionally stored as data rather than 20,000 separate files so the site remains manageable and fast to deploy.

Some entries are marketplace-expansion/unverified listings. Verify seller, exact variant, stock and image/product match before commercial use.
