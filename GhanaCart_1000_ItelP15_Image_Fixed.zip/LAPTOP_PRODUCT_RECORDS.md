# GhanaCart laptop product records

Added 25 named laptop product listings across HP, Lenovo, Dell, ASUS, Acer, Apple, MSI and Microsoft. Each listing has an individual SKU, product ID, model, description, indicative GH₵ price, sample stock value, specifications, and its own local product illustration under `assets/images/laptops/`.

**Important:** The images are GhanaCart-made illustrative product artwork, not manufacturer photography. Prices and stock are demo/indicative values and must be confirmed with the supplier before the store accepts real orders. Laptop configurations vary by regional SKU.

Open the category at `category.html?category=laptops`.
