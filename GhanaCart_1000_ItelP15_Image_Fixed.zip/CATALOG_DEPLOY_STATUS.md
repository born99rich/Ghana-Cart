# GhanaCart expanded-category catalog

- Every expanded category targets at least 150 real source records.
- Source: Shopify Product Catalogue, Apache-2.0.
- The loader first fills each category to the 150 minimum, then continues toward 10,000 total.
- Product images are taken only from the exact source record.
- No synthetic product records, duplicate padding, or cross-product image substitution.
- The browser fetches the source through the Hugging Face Dataset Viewer API; no 9.5 GB dataset is embedded in this static ZIP.
