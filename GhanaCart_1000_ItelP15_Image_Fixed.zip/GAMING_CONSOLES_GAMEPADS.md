# GhanaCart Gaming Consoles & Gamepads

Added 20 gaming products to the `gaming` department: 11 consoles/handheld systems and 9 gamepads/controllers.

## Image sources
The product image URLs use real photographs hosted on Wikimedia Commons. Each source page should be checked for its stated Creative Commons/public-domain license and attribution requirements before commercial deployment.

Sources include: PlayStation 5, PlayStation 5 Pro, Xbox Series X, Nintendo Switch 2, Nintendo Switch OLED, Steam Deck, ROG Xbox Ally X, DualSense, DualSense Edge, Xbox Wireless Controller, Xbox Elite Series 2, Nintendo Switch Pro Controller, Nintendo Switch 2 Pro Controller, Joy-Con and DualShock 4.

Official product references used to verify model names/features include PlayStation, Xbox, Nintendo and Steam Deck product pages.
