# GhanaCart 10K Catalog Expansion

This build expands the storefront from the 332 embedded GhanaCart products toward a 10,000-product catalog by loading real records from the Shopify Product Catalogue dataset through the Hugging Face Dataset Viewer API.

The Shopify Product Catalogue is published under Apache-2.0 and contains 48,289 real e-commerce product records with product title, description, image, brand and category fields.

The storefront adds records until it reaches 10,000 total unique product names/brands. It does not invent a product name, model or image. Imported reference records without a commercial price are shown as **Price pending** rather than assigning a fabricated price.

The existing 332 GhanaCart records remain the priced/purchasable catalog. A commercial supplier feed can later replace `priceStatus: pending_supplier_price` records with real price, stock and SKU data through the existing catalog importer.
