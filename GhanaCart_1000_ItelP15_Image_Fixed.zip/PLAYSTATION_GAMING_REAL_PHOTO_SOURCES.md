# GhanaCart Gaming — PlayStation Product Records

The Gaming category is now PlayStation-focused and contains 30 individual product records: PS5, PS4, PS3, PS2, PlayStation Classic, PSP, PS Vita, PlayStation Portal, DualSense/DualShock controllers, PS VR2, PULSE audio, HD Camera and PS5 Disc Drive.

Images are real product photographs sourced from Wikimedia Commons or retailer-hosted product photography. Some are exact model photos; where an exact photo was not verified, a real family/model photo is used and the record is marked for configuration verification. Review each image's license/terms before using it commercially.

Official PlayStation product references: https://www.playstation.com/en-us/accessories/
