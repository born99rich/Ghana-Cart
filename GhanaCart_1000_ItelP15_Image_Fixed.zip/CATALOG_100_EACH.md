# GhanaCart — 100 Products Per Category

The storefront catalog loader targets a minimum of 100 product listings in every registered category, including the focused shopping categories. Products are sourced from the Shopify Product Catalogue dataset through the Hugging Face Dataset Viewer at runtime; source product names/images are preserved.

The catalog loader registers the focused categories and fills them to the minimum before continuing toward the larger catalog target.
