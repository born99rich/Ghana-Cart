# Laptop image update

GhanaCart laptop cards no longer use the GhanaCart-made SVG illustrations. They now point to real product photography hosted by manufacturer, retailer, or product-catalog pages discovered during the update. Exact model photos are used where a verified image URL was exposed; otherwise a verified photo from the same product family/brand is used rather than a synthetic illustration.

Before commercial launch, verify image usage rights/licensing and confirm the exact regional SKU/configuration with the supplier.
